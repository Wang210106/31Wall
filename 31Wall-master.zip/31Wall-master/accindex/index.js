Page({
    data: {
      username: '',
      password: ''
    },
  
    inputUsername: function(e) {
      this.setData({
        username: e.detail.value
      });
    },
  
    inputPassword: function(e) {
      this.setData({
        password: e.detail.value
      });
    },
  
    login: function() {
      const { username, password } = this.data;
      if (username === 'admin' && password === '123456') {
        wx.navigateTo({
          url: '/pages/user/user?username=' + username
        });
      } else {
        wx.showToast({
          title: '用户名或密码错误',
          icon: 'none'
        });
      }
    }
  });