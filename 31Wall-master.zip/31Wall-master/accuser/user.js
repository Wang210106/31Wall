Page({
    data: {
      username: '',
      email: ''
    },
  
    onLoad: function(options) {
      this.setData({
        username: options.username || 'admin'
      });
    },
  
    inputUsername: function(e) {
      this.setData({
        username: e.detail.value
      });
    },
  
    inputEmail: function(e) {
      this.setData({
        email: e.detail.value
      });
    },
  
    save: function() {
      const { username, email } = this.data;
      wx.showToast({
        title: '保存成功',
        icon: 'success'
      });
      // 这里可以添加保存逻辑，比如调用API保存用户信息
    }
  });